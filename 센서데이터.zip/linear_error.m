data = table2array(readtable("sensor_1_to_3cm.xlsx"));
x_data = linspace(1, 3, 100)';
data_1 = data(:,1);

% 선형 회귀 모델 생성
linear_model = fitlm(x_data, data_1);
coefficients = table2array(linear_model.Coefficients(:, 'Estimate'));
intercept = coefficients(1);
slope = coefficients(2);

% 선형 회귀식 작성
y_linear_1 = intercept + slope.*x_data; 


% 선형 오차 확인
u_l = (data_1 - y_linear_1)/4.2 * 100;
u_lmax = max(u_l);

% 데이터 플로팅
plot(x_data, data_1, "b");
grid on
hold on
plot(x_data, y_linear_1, "r")
xlabel("Input [cm] ")
ylabel("Output[V]")
title("Linear Error")
legend("Actual Output", "Linear Regression")
