data = table2array(readtable("sensor_1_to_3cm.xlsx"));
x_data = linspace(1, 3, 100)';
data_1 = data(:,1);

s_x = 0;
dof = 0; % 자유도 N-1


for i = 1:30
    d = data(:,i);
    variation = var(d);
    s_x = s_x + (variation^2)*99;
    dof = dof + 99;
end

pooled_standard_deviation = sqrt(s_x/dof);

maximum_expected_error = 2 * pooled_standard_deviation / 4.2 * 100;