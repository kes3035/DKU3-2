% 주어진 데이터셋



array1_1 = table2array(readtable("sensor_1_1cm.xlsx"));
data_1_1 = array1_1(:,1);

array1_2 = table2array(readtable("sensor_1_2cm.xlsx"));
data_1_2 = array1_2(:,1);


array1_3_1 = table2array(readtable("sensor_1_3_1cm.xlsx"));
data_1_3_1 = array1_3_1(:,1);

array1_3_2 = table2array(readtable("sensor_1_3_1cm.xlsx"));
data_1_3_2 = array1_3_2(:,1);



x = 1:1:300;
y_linear_1_1 = 2.34474504 + 0.00001176.*x;
y_linear_1_2 = 2.403477356643368 + 6.403247863246846e-05.*x + -4.9365449364371955e-09.*x.^2;
y_linear_1_3 = 2.514517671328687 + -4.634211344242775e-06.*x + -6.435767935763219e-08.*x.^2;

r_o = 4.2;
u_l = ((data_1_3).*4./4.2 - (transpose((y_linear_1_3))).*4./4.2).*100;
u_lmax = max(u_l);


%plot(x,(data_1_1).*4./4.2 - (y_linear_1_1).*4./4.2, "r");
%grid on
%hold on
%yline(1, LineWidth=1, Color="g")

%title("3cm에 대한 센서1 측정값과 실제값")
%xlabel("수집된 데이터 인덱스")
%ylabel("선형오차Y-Y_L")
%legend("선형오차", "실제값")


